# HIT
Neural Predicting Higher-order Patterns in Temporal Networks

