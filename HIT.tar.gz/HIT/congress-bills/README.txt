The simplices in this dataset correspond to co-sponsorship of bills in the
United States Congress, derived from James Fowler's datasets:
http://jhfowler.ucsd.edu/cosponsorship.htm
Each simplex represents one bill, and the set of vertices is the set consisting
of the sponsor and co-sponsors. Timestamps are in days and represent when
the bill was introduced.

The file congress-bills-names.txt contains the names of the congresspersons.
